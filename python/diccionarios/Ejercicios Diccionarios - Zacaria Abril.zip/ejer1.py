unDict= {'a': 100, 'b': 200, 'c': 300}

for c,v in unDict.items():
    if v==200:
        print(f"El valor {v} si existe")
    #else: 
        #print("No existe")