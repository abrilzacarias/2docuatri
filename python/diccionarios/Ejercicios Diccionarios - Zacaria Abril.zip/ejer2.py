nroIngresado= int(input("Ingrese un número: "))
dict = {}
for i in range(1,nroIngresado+1):
    dict[i]=i**2
print(dict)