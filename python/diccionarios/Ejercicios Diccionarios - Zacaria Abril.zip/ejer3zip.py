clave= ['diez', 'veinte',
'treinta']
valores= [10, 20, 30]
dictc = dict(zip(clave, valores))

print(dictc)