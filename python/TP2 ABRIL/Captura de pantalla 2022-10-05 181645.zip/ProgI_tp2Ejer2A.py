auto1=70
auto2=250

while auto1!=auto2:
    auto1+=1
    auto2-=1
    if auto1==auto2:
        print(auto1, auto2)

#160se

