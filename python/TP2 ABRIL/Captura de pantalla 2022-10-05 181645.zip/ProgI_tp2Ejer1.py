c=0
validacionCant=False
validacionEspecial=False 
validacionNum=False
validacionVocal=False
j=True

while j==True:
    palabra = input("Ingrese una contraseña: ")
    for unaLetra in palabra: 
        c+=1 
    if (c>=8):
        validacionCant=True
    if (unaLetra=="A") or (unaLetra=="E") or (unaLetra=="I") or (unaLetra=="O") or (unaLetra=="U"):
        validacionVocal=True
    if (unaLetra=="0") or (unaLetra=="1") or (unaLetra=="2") or (unaLetra=="3") or (unaLetra=="4") or (unaLetra=="5"):
        validacionNum=True
    if (unaLetra=="#") or (unaLetra=="@"):
        validacionEspecial= True
    if (validacionCant==True) & (validacionVocal==True) & (validacionNum==True) & (validacionEspecial==True):
        print("¡Su contraseña es válida!")
        j=False
    else: 
        print("Contraseña incorrecta ¡Intente nuevamente!")