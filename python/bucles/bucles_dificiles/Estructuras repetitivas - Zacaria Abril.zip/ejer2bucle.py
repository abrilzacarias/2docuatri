nro = int(input("Ingrese un número para saber su tabla de multiplicación: "))
nroFinal = int(input("Ingrese el número final de la tabla: "))
i = 1
for i in range(i, nroFinal+1):
    print(f'{nro}*{i} = {nro*i}' )