for i in range(0, 5):
        for j in range(0, i+1):
            print("* ",end="") #end es para no se haga el salto de linea
        print("\r") #/r es para salto de linea

for i in range(4, 0, -1):
    for j in range(i,):
        print("* ",end="")
    print("\r")