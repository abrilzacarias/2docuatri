n = 5

for i in range(n, 0, -1):
    for j in range(i, 0, -1):
        print(j, end=" ")
    print()

'''line = 5
while line >= 1:
    number = line
    while number > 0:
        print(number, end=' ')
        number = number - 1
    line = line - 1
    print('')'''