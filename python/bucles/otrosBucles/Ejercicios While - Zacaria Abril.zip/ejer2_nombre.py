nombre = input("Ingrese un nombre: ")
veces = int(input("Ingrese la cantidad de veces a mostrar el nombre: "))

for indice in range(1, veces+1):
    print(f'número: {indice} nombre: {nombre} ')