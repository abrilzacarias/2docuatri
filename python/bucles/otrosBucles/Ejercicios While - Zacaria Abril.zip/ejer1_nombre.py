nombre = input("Ingrese un nombre: ")
for indice in range(1001):
    print(f'número: {indice} nombre: {nombre} ')