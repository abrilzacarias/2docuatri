def saludar():
    print("Hola mundo")

saludar()