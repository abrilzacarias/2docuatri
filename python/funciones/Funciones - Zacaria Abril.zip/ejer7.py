def validarEmail(pDireccion):
    letra=0
    valido=False
    for letra in pDireccion:
        if (letra=="@"):
            valido=True
    if (valido==True):
        return f"La direccion {pDireccion} es válida."
    else:
        return f"La direccion {pDireccion} es inválida."

direccion=input("Ingrese su dirección de email: ")
print(validarEmail(direccion))
