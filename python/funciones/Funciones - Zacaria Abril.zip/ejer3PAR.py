def parImpar(num1):
    if ((num1%2)==0):
        print(f'{num1} PAR ')
    else:
        print(f'{num1} IMPAR ')

nro1=int(input("Ingrese el número: "))
parImpar(nro1)
