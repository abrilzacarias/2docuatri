def sumarDosNumeros(pNum1,pNum2 = 0): 
    resultado = 0
    resultado = pNum1+pNum2
    return resultado

print(sumarDosNumeros(10, 20))