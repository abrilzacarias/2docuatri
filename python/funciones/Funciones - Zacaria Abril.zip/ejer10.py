import math

def areaCirculo(pRadio):
    area = (radio**2)*(math.pi)
    return area

radio = float(input("Ingrese el radio del circulo: "))

print(f"El área del circulo es de: {areaCirculo(radio)} ")